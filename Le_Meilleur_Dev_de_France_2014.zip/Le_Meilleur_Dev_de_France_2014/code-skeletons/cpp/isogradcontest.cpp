#include "exercise.hpp"

using namespace std;

int main(){
    ContestExerciseImpl i;
    i.main();

    return 0;
}
