#ifndef DEF_CONTESTEXERCISEIMPL
#define DEF_CONTESTEXERCISEIMPL

#include <iostream>

class ContestExerciseImpl {

    public :
        ContestExerciseImpl();

        void main();

        void localEcho(std::string thestring);
};

#endif
