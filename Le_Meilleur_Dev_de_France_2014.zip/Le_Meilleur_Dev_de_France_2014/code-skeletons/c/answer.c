/*******
 * Read input from STDIN
 * Use printf(...) or fprintf( stdout, ...) to output your result.
 * Use:
 *  localPrint( char* mystring)
 * to display variable in a dedicated area.
 * ***/
#include <stdlib.h>
#include <stdio.h>

int main() {
   char s[1024];
       
    while (scanf("%s", &s) != EOF) {
        //
	    // Lisez les données ici et effectuez votre traitement ici 
		//
    }
    
    // Vous pouvez aussi effectuer votre traitement ici après avoir lu toutes les données 
    return 0;
}

/* 
 * DO NOT PASTE THIS UTILITY CODE BACK INTO THE BROWSER WINDOW
 */
int localPrint(char* val){
  printf("%s", val);
}