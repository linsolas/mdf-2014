package com.isograd.exercise;

import java.io.InputStream;

public class RunTestCases {

    public static void main(String[] argv) throws Exception {
        InputStream inputStream = RunTestCases.class.getResourceAsStream("/input1.txt");
        System.setIn(inputStream);
        IsoContest.main(new String[0]);
    }
}
